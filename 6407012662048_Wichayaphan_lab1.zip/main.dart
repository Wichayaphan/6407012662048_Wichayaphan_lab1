import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "My Flutter App",
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 252, 200, 132),
        appBar: AppBar(
          actions: [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 5, 0),
              child: Icon(
                Icons.search,
                size: 40,
                color: Color.fromARGB(255, 116, 116, 117),
              ),
            )
          ],
          leading: Icon(
            Icons.menu,
            color: Color.fromARGB(255, 255, 255, 255),
            size: 40,
          ),
          backgroundColor: Color.fromARGB(146, 172, 82, 31),
          title: const Text('Mix Profile UI'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Color.fromARGB(255, 253, 70, 70),
                    width: 4.0,
                  ),
                ),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                    'https://img.freepik.com/free-photo/young-bearded-man-with-striped-shirt_273609-5677.jpg?w=2000',
                  ),
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Wichayaphan Traithipthomrongchoke',
                style: TextStyle(
                  fontSize: 20,
                  color: Color.fromARGB(255, 124, 56, 0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'College Student',
                style: TextStyle(
                  fontSize: 16,
                  color: Color.fromARGB(255, 189, 92, 12),
                ),
              ),
              SizedBox(height: 16),
              Text(
                '*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*',
                style: TextStyle(
                  fontSize: 18,
                  color: Color.fromARGB(255, 124, 56, 0),
                  fontWeight: FontWeight.bold,
                  
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Lorem ipsum dolor sit amet. At esse tempora eos sunt impedit cum dolor fugit qui commodi quas est velit fugit et omnis quidem qui totam voluptatem.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Color.fromARGB(255, 189, 92, 12),
                ),
              ),
              SizedBox(height: 16),
              ListTile(
                leading: Icon(Icons.email),
                title: Text('s6407012662048@email.kmutnb.ac.th.com'),
              ),
              ListTile(
                leading: Icon(Icons.phone),
                title: Text('+66-**********'),
              ),
              ListTile(
                leading: Icon(Icons.location_on),
                title: Text('Nonthaburi, THAI'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}