import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "My Flutter App",
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 252, 200, 132),
        appBar: AppBar(
          actions: [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 5, 0),
              child: Icon(
                Icons.search,
                size: 40,
                color: Color.fromARGB(255, 116, 116, 117),
              ),
            )
          ],
          leading: Icon(
            Icons.menu,
            color: Color.fromARGB(255, 255, 255, 255),
            size: 40,
          ),
          backgroundColor: Color.fromARGB(146, 172, 82, 31),
          title: const Text('Mix Profile UI'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Color.fromARGB(255, 253, 70, 70),
                    width: 4.0,
                  ),
                ),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                    'https://img.freepik.com/free-photo/young-bearded-man-with-striped-shirt_273609-5677.jpg?w=2000',
                  ),
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Wichayaphan Traithipthomrongchoke',
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: "EncodeSans",
                  color: Color.fromARGB(255, 124, 56, 0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'College Student',
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: "EncodeSans",
                  color: Color.fromARGB(255, 189, 92, 12),
                ),
              ),
              SizedBox(height: 16),
              Text(
                '*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*',
                style: TextStyle(
                  fontSize: 18,
                  color: Color.fromARGB(255, 124, 56, 0),
                  fontWeight: FontWeight.bold,
                  
                ),
              ),
              SizedBox(height: 8),
              Text(
                "Hi, I'm Wichayaphan Traithipthomrongchoke. I'm currently a college student study at KMUTNB in IBIT. Currently I'm 21 yearsold live in Nonthaburi.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: "EncodeSans",
                  color: Color.fromARGB(255, 189, 92, 12),
                ),
              ),
              SizedBox(height: 16),
              Text(
                '*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*',
                style: TextStyle(
                  fontSize: 18,
                  color: Color.fromARGB(255, 124, 56, 0),
                  fontWeight: FontWeight.bold,
                  
                ),
              ),
              SizedBox(height: 16),
              Text(
                "My Email : s6407012662048@kmutnb.ac.th",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: "EncodeSans",
                  color: Color.fromARGB(255, 124, 56, 0),
                ),
              ),
              SizedBox(height: 24),
              Text(
                "My Tel : 086-***-****",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: "EncodeSans",
                  color: Color.fromARGB(255, 124, 56, 0),
                ),
              ),
              SizedBox(height: 32),
              Text(
                "My Line_ID : mix_rb129",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: "EncodeSans",
                  color: Color.fromARGB(255, 124, 56, 0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}